self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "8a8a1c167b8bfccc04cea2a0e078234e",
    "url": "/admin/index.html"
  },
  {
    "revision": "e8dfcc6ab32c71756635",
    "url": "/admin/static/css/main.10078b94.chunk.css"
  },
  {
    "revision": "4893809409bd7aa4c556",
    "url": "/admin/static/js/2.5aaf71f6.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "/admin/static/js/2.5aaf71f6.chunk.js.LICENSE.txt"
  },
  {
    "revision": "e8dfcc6ab32c71756635",
    "url": "/admin/static/js/main.4b719dac.chunk.js"
  },
  {
    "revision": "89859961ce651d039cd8",
    "url": "/admin/static/js/runtime-main.82aeceb4.js"
  }
]);